document.getElementById("rollButton").addEventListener("click", function() {
    // Generate random numbers between 1 and 6 for two dice
    const dice1 = Math.floor(Math.random() * 6) + 1;
    const dice2 = Math.floor(Math.random() * 6) + 1;
  
    // Update the dice divs with the rolled numbers
    document.getElementById("dice1").innerText = dice1;
    document.getElementById("dice2").innerText = dice2;
  
    // playtesting
    const sum = dice1 + dice2;
  
    // Displaying result message
    let resultMessage;
    if (sum === 7 || sum === 11) {
      resultMessage = "You win!";
    } else {
      resultMessage = "You lose!";
    }
    document.getElementById("result").innerText = `You rolled a ${sum}. ${resultMessage}`;
  });