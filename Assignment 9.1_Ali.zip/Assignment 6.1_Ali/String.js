const form = document.getElementById('userForm');
const message = document.getElementById('message');
const secretMessage = document.getElementById('secretMessage');
const palindromeSection = document.getElementById('palindromeSection');
const palindromeMessage = document.getElementById('palindromeMessage');

form.addEventListener('submit', function(event) {
   
    event.preventDefault();

    // I'm clearing any previous messages
    message.textContent = '';
    secretMessage.style.display = 'none';

    // Gather user input
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const zipCode = document.getElementById('zipCode').value.trim();

    // Concatenate first and last name for length check
    const fullName = firstName + ' ' + lastName;

    // Check if full name is within length limit
    if (fullName.length > 20) {
        message.textContent = 'Full name should be less than 20 characters.';
        return; // Stop execution if invalid
    }

    // Validate the zip code format
    const zipCodePattern = /^\d{5}$/; // Pattern for 5 digits
    if (!zipCodePattern.test(zipCode)) {
        message.textContent = 'Zip code should be 5 digits long.';
        return;
    }

    // Display the secret message and palindrome checker section
    message.textContent = '';
    secretMessage.style.display = 'block';
    palindromeSection.style.display = 'block';
});

// Function to check if a string is a palindrome
function isPalindrome(word) {
    // Remove spaces and make lowercase for comparison
    const cleanedWord = word.replace(/\s+/g, '').toLowerCase();
    // Check if the word reads the same forward and backward
    return cleanedWord === cleanedWord.split('').reverse().join('');
}

// Function to start the palindrome checking loop
function startPalindromeCheck() {
    let continueChecking = true;

    // Loop to allow multiple entries
    while (continueChecking) {
        // Prompt user for a word
        let userInput = prompt("Enter a word to check if it's a palindrome:");

        if (userInput) {
            // Check if the input word is a palindrome
            if (isPalindrome(userInput)) {
                palindromeMessage.textContent = `"${userInput}" is a palindrome!`;
            } else {
                palindromeMessage.textContent = `"${userInput}" is not a palindrome.`;
            }

            // Ask if the user wants to continue
            continueChecking = confirm("Would you like to enter another word?");
        } else {
            // Exit loop if no input is given
            continueChecking = false;
        }
    }
    palindromeMessage.textContent += " Thank you for using the palindrome checker!";
}
