let interval;
const memeImage = document.getElementById('memeImage');

function moveMeme() {
    const x = Math.random() * (window.innerWidth - memeImage.clientWidth);
    const y = Math.random() * (window.innerHeight - memeImage.clientHeight);
    memeImage.style.transform = `translate(${x}px, ${y}px)`;
}

function startMovement() {
    interval = setInterval(moveMeme, 1000); // Move every second
    toggleButtons(true);
}

function stopMovement() {
    clearInterval(interval);
    toggleButtons(false);
}

function toggleButtons(isMoving) {
    document.getElementById('startButton').disabled = isMoving;
    document.getElementById('stopButton').disabled = !isMoving;
}
