document.getElementById("rollButton").addEventListener('click', rollDice);

  function rollDice() { 
    //The random dice rolls between 1 and 6 for each dice 
    const dice1 = Math.floor(Math.random() * 6) + 1;
    const dice2 = Math.floor(Math.random() * 6) + 1;

    //Displaying the Dice rolls
    document.getElementById('dice1').textContent = dice1; 
    document.getElementById('dice2').textContent = dice2;

    //Determining the Results
    //Logic Error is that instead of checking if the total is even, it checks if its odd.
    const total = dice1 + dice2;
    if (total % 2===1){ // Intentional error
      document.getElementById('result').textContent = 'You win!';
    } else {
      document.getElementById('result').textContent = 'You lose!';
    }
  }