document.querySelectorAll('.class-box').forEach(box => {
    box.addEventListener('mouseover', () => {
      box.style.backgroundColor = '#e3f2fd';
    });
  
    box.addEventListener('mouseout', () => {
      box.style.backgroundColor = '#fff';
    });
  });
  