    const form = document.getElementById('userForm');
    const message = document.getElementById('message');
    const secretMessage = document.getElementById('secretMessage');

  
    form.addEventListener('submit', function(event) {
      
        event.preventDefault();

      // Inputed values 
        message.textContent = '';
        secretMessage.style.display = 'none';


        const firstName = document.getElementById('firstName').value.trim();
        const lastName = document.getElementById('lastName').value.trim();
        const zipCode = document.getElementById('zipCode').value.trim();

        // Firse name and last name + added spaces in them
        const fullName = firstName + ' ' + lastName;

        
        if (fullName.length > 20) {
            message.textContent = 'Full name should be less than 20 characters.';
            return; // This stops the evecution if its invald
        }
        // Verifying the Zip code
        const zipCodePattern = /^\d{5}$/; // <-- Pattern of 5 digits
        if (!zipCodePattern.test(zipCode)) {
            message.textContent = 'Zip code should be 5 digits long.';
            return; 
        }

       // once both of them are inputed, its shows the secret message 
        message.textContent = '';
        secretMessage.style.display = 'block'; //This show the secret message 
    });